-- ========================================================
-- Cloud Office v1.0.0-rc.1
-- ========================================================

-- Step 1: Open this file into 'SQL Server Management Studio'.

-- Step 2: Select the Database Accolade is using.

-- Step 3: Run the script.

PRINT 'Cloud Office (1.0.0-rc.1) Started - ' + CONVERT(nvarchar, GETDATE(), 121)

-- ========================================================
-- Shut off the rowcounts for the duration of this session.
-- ========================================================

SET NOCOUNT ON
GO

-- ========================================================
-- Add entry to SSC_DBInstallHistory.
-- ========================================================
DECLARE @InstallName NVARCHAR(MAX)
DECLARE @InstallVersion NVARCHAR(64)
DECLARE @InstallDate DATETIME
DECLARE @DBID INT
DECLARE @DBName NVARCHAR(MAX)
DECLARE @ExecutedBy NVARCHAR(MAX)

SET @DBID = DB_ID()

SELECT @DBName = D.[Name]
FROM SYS.DATABASES D WITH (NOLOCK)
WHERE D.Database_ID = @DBID

SET @InstallName = N'Cloud Office ' + @DBName
SET @InstallVersion = N'Cloud Office v1.0.0-rc.1'
SET @InstallDate = GETDATE()
SET @ExecutedBy = SUSER_SNAME()

INSERT INTO SSC_DBInstallHistory (Name,
   InstallationDate,
   [Version],
   ExecutedBy)
VALUES (@InstallName,
   @InstallDate,
   @InstallVersion,
   @ExecutedBy)
GO

PRINT 'Cloud Office (1.0.0-rc.1) Completed - ' + CONVERT(nvarchar, GETDATE(), 121)
GO

--<eof>
